// Node 18+: node tests/browser-check.cjs "path/to/brave.exe or chrome.exe"
// A fresh headless browser profile; never accesses a logged-in browser.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {pathToFileURL}=require('node:url'),{spawnSync}=require('node:child_process');
const browser=process.argv[2] || 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const parent=path.resolve(os.tmpdir()),profile=fs.mkdtempSync(path.join(parent,'daily-pause-test-'));
try {
  const result=spawnSync(browser,['--headless','--disable-gpu','--no-first-run','--no-default-browser-check',`--user-data-dir=${profile}`,'--virtual-time-budget=15000','--dump-dom',pathToFileURL(path.join(__dirname,'browser.html')).href],{encoding:'utf8',timeout:45000,windowsHide:true,maxBuffer:2*1024*1024});
  console.log(result.stdout?.match(/<pre id="results">([\s\S]*?)<\/pre>/)?.[1] || result.error?.message || result.stderr?.slice(-2500));
  process.exitCode=result.stdout?.includes('data-tests="passed"')?0:1;
} finally {
  // Only remove the newly created test profile beneath the resolved temp directory.
  if(path.resolve(profile).startsWith(parent+path.sep) && path.basename(profile).startsWith('daily-pause-test-')) fs.rmSync(profile,{recursive:true,force:true,maxRetries:3});
}
