let mock, number;
const $=id=>document.getElementById(id);
function render(){
  const r=mock.result;
  $('screen').textContent=mock.item.kind==='episode'?`Mock Show · S1 E${number}`:'Mock movie';
  $('state').textContent=JSON.stringify({date:r.date,playing:mock.playing,position:mock.position,minutes:r.today.ms/60000,episodes:r.count,extensionsUsed:r.today.extensionsUsed,phase:r.today.phase,allowance:r.today.allowance,log:r.today.episodes},null,2);
  $('prompt').hidden=!r.blocked;
  $('summary').textContent=`Limit: ${r.settings.episodes} episodes / ${r.settings.minutes} minutes. Watched: ${r.count} episodes / ${(r.today.ms/60000).toFixed(1)} minutes. ${r.today.stopped?'Stopped until tomorrow.':''}`;
  $('friction').textContent=r.notice||r.cause;
  const seconds=Math.ceil(r.friction.waitMs/1000),wait=`${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`;
  $('extra-episode').textContent=seconds?`Watch another episode (${wait})`:'Watch another episode';
  $('extra-episode').hidden=r.action!=='episode';
  $('reason-label').hidden=!r.friction.reasonRequired||!r.action;
  const ready=!r.friction.waitMs&&(!r.friction.reasonRequired||$('reason').value.trim()===r.friction.phrase);
  $('extra-episode').disabled=!ready;
}
function reset(){mock=new MockPlayer();number=1;mock.state.settings.episodes=1;mock.state.settings.minutes=20;$('reason').value='';render();}
function advance(seconds){for(let i=0;i<seconds;i++){if(mock.result.blocked){mock.pause();break;}mock.step();}render();}
$('play').onclick=()=>{if(!mock.result.blocked)mock.play();render();};
$('pause').onclick=()=>{mock.pause();render();};
$('end').onclick=()=>{mock.end();render();};
$('advance').onclick=()=>{if(!mock.result.blocked)mock.play();advance(60);};
$('next').onclick=()=>{mock.next(String(++number));if(mock.result.blocked)mock.pause();render();};
$('movie').onclick=()=>{mock.item={kind:'movie'};mock.key='movie';mock.position=0;mock.sample();render();};
$('seek').onclick=()=>{mock.seeking=true;mock.position+=600;mock.sample();mock.seeking=false;mock.sample();render();};
$('midnight').onclick=()=>{const date=new Date(mock.now);date.setHours(23,59,59,500);mock.now=date.getTime();mock.sampler.reset();mock.sample();mock.step();render();};
$('reset').onclick=reset;
for(const [id,choice] of [['stop','stop'],['extra-episode','episode']]) $(id).onclick=()=>{mock.choose(choice,{reason:$('reason').value});if(!mock.result.blocked&&!mock.ended)mock.play();render();};
$('skip-wait').onclick=()=>{mock.wait(mock.result.friction.waitMs);render();};
$('reason').oninput=render;
reset();setInterval(()=>{if(mock.result.blocked){mock.wait(1000);render();}else advance(1);},1000);
