// Only the media clock and Chrome transport are mocked. The production detector,
// content script, DOM events, shadow prompt, and limit engine run unchanged.
const fixture = {
  location: { pathname: '/watch/1' }, clock: 10000, position: 0, paused: true, ended:false,
  state: LimitEngine.fresh(), heartbeats: [], storageListeners: [], clicks: 0, number: 1,
  video: document.querySelector('video'), next: document.querySelector('[data-uia="control-next"]')
};
fixture.state.settings.episodes=1;
fixture.state.settings.minutes=500;
fixture.state.settings.diagnostic=true;
const BrowserDetector=NetflixDetection.NetflixDetector, realWatchKey=NetflixDetection.watchKey;
NetflixDetection.NetflixDetector=class extends BrowserDetector { observe(doc=document,loc=fixture.location){return super.observe(doc,loc);} };
NetflixDetection.watchKey=()=>realWatchKey(fixture.location);
Object.defineProperty(performance,'now',{value:()=>fixture.clock});
window.setInterval=fn=>fixture.heartbeats.push(fn);
for(const [key,get] of Object.entries({currentTime:()=>fixture.position,paused:()=>fixture.paused,ended:()=>fixture.ended,readyState:()=>4,seeking:()=>false,playbackRate:()=>1})) Object.defineProperty(fixture.video,key,{get});
fixture.video.play=async()=>{if(fixture.paused){fixture.paused=false;fixture.video.dispatchEvent(new Event('play'));}};
fixture.video.pause=()=>{if(!fixture.paused){fixture.paused=true;fixture.video.dispatchEvent(new Event('pause'));}};
fixture.change=(number)=>{
  fixture.number=number;fixture.location.pathname=`/watch/${number}`;fixture.position=0;fixture.ended=false;
  document.querySelector('.video-title').innerHTML=`<span>Mock Show</span><span>Episode ${number}</span><span>Chapter ${number}</span>`;
};
fixture.next.addEventListener('click',()=>{fixture.clicks++;fixture.change(fixture.number+1);void fixture.video.play();});
const attachShadow=Element.prototype.attachShadow;
Element.prototype.attachShadow=function(options){return attachShadow.call(this,{...options,mode:'open'});};
window.chrome={storage:{onChanged:{addListener:fn=>fixture.storageListeners.push(fn)}},runtime:{getManifest:()=>({version:'test'}),sendMessage:async message=>{
  const now=new Date(2026,8,29,12).getTime()+fixture.clock;
  if(message.type==='tick')return LimitEngine.tick(fixture.state,message.session,message,now);
  if(message.type==='choice')return LimitEngine.choose(fixture.state,message,now);
  if(message.type==='navigation')return LimitEngine.navigationVerdict(fixture.state,message.targetId,now,message.item,message.watchId,message.session);
  if(message.type==='diagnostic'){fixture.diagnostic=message.observation;return {ok:true};}
  return LimitEngine.verdict(fixture.state,null,now,{mode:'summary'});
}}};
fixture.settle=async()=>{for(let i=0;i<3;i++)await new Promise(resolve=>setTimeout(resolve,0));};
fixture.settings=async patch=>{
  const oldValue=structuredClone(fixture.state);Object.assign(fixture.state.settings,patch);
  for(const listener of fixture.storageListeners)listener({state:{oldValue,newValue:structuredClone(fixture.state)}},'local');
  await fixture.settle();
};
fixture.tick=async()=>{fixture.clock+=1000;if(!fixture.paused)fixture.position++;await fixture.heartbeats[0]();await fixture.settle();};
