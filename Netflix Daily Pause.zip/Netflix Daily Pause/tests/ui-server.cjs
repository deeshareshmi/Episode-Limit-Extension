const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..');
function createServer(){return http.createServer((req,res)=>{
  try{
    const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
    const file=path.resolve(root,'.'+pathname);
    if(!file.startsWith(root+path.sep)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
    const ext=path.extname(file);let body=fs.readFileSync(file);
    if(pathname==='/options.html'||pathname==='/popup.html')body=body.toString('utf8').replace('<script src="engine.js">','<script src="tests/ui-bridge.js"></script><script src="engine.js">');
    res.writeHead(200,{'Content-Type':({'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'})[ext]||'application/octet-stream','Cache-Control':'no-store'}).end(body);
  }catch{res.writeHead(404).end();}
});}
module.exports=createServer;
if(require.main===module){const server=createServer();server.listen(Number(process.argv[2]||0),'127.0.0.1',()=>console.log(`http://127.0.0.1:${server.address().port}/tests/ui.html`));}
