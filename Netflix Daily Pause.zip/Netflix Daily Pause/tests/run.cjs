// Run with Node.js 18+: node tests/run.cjs
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
for (const name of ['engine.js','tracker.js','detector.js','tests/tests.js']) {
  const filename=path.join(__dirname,'..',name);
  vm.runInThisContext(fs.readFileSync(filename,'utf8'),{filename});
}
for(const r of testResults) console.log(`${r.pass?'PASS':'FAIL'} ${r.name}${r.error?': '+r.error:''}`);
console.log(`${testResults.filter(r=>r.pass).length}/${testResults.length} passed`);
process.exitCode=testResults.every(r=>r.pass)?0:1;
