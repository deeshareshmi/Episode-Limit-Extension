// Injected by the local test server, never included in the packaged extension pages.
window.chrome=parent.uiFixture.makeChrome();
window.Date=parent.Date;
