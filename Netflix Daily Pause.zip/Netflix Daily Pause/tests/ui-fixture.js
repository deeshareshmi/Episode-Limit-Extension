/* Test-only browser transport. Production background, forms and charts run unchanged. */
(() => {
  const RealDate=Date,copy=structuredClone;
  const fixture=window.uiFixture={clock:new RealDate(2026,9,1,12).getTime(),listeners:[],handlers:{},rules:[],alarms:{},opened:[],optionsOpened:0};
  window.Date=class extends RealDate{constructor(...args){super(...(args.length?args:[fixture.clock]));}static now(){return fixture.clock;}};
  const state=LimitEngine.fresh();
  for(let i=0;i<26;i++){
    if(i===4||i===11)continue;
    const date=new Date(fixture.clock);date.setDate(date.getDate()-i);
    const day=LimitEngine.day(state,date.getTime());day.ms=i===2?0:(18+(i*13)%77)*60000;
    if(day.ms)day.episodes.a={id:'a',title:'A Quiet Journey',season:1,episode:1+i,episodeTitle:'The next chapter',ms:day.ms-20000,completed:true};
  }
  const day=LimitEngine.day(state,fixture.clock);day.episodes.partial={id:'partial',title:'A second story',season:2,episode:1,ms:20000};
  fixture.database={state};
  fixture.makeChrome=()=>({
    runtime:{getURL:p=>`chrome-extension://fixture/${p}`,getManifest:()=>({version:'0.5.1'}),openOptionsPage:async()=>{fixture.optionsOpened++;},
      sendMessage:message=>fixture.send(message),onMessage:{addListener:fn=>fixture.listener=fn},onStartup:{addListener:fn=>fixture.handlers.startup=fn},onInstalled:{addListener:fn=>fixture.handlers.installed=fn}},
    storage:{onChanged:{addListener:fn=>fixture.listeners.push(fn)},local:{get:async key=>copy({[key]:fixture.database[key]}),set:async values=>{
      const changes={};for(const [key,value] of Object.entries(values))if(JSON.stringify(fixture.database[key])!==JSON.stringify(value)){changes[key]={oldValue:copy(fixture.database[key]),newValue:copy(value)};fixture.database[key]=copy(value);}
      if(Object.keys(changes).length)for(const fn of fixture.listeners)fn(copy(changes),'local');
    }}},
    tabs:{create:async options=>{fixture.opened.push(options);}},
    declarativeNetRequest:{getDynamicRules:async()=>copy(fixture.rules),updateDynamicRules:async({removeRuleIds,addRules})=>{fixture.rules=fixture.rules.filter(r=>!removeRuleIds.includes(r.id)).concat(copy(addRules));}},
    alarms:{onAlarm:{addListener:fn=>fixture.handlers.alarm=fn},get:async name=>fixture.alarms[name],create:async(name,value)=>{fixture.alarms[name]={name,scheduledTime:value.when};},clear:async name=>{delete fixture.alarms[name];}}
  });
  fixture.send=message=>new Promise(resolve=>fixture.listener(copy(message),{tab:{id:1},url:'https://www.netflix.com/watch/99'},result=>resolve(copy(result))));
  window.chrome=fixture.makeChrome();window.importScripts=()=>{};
  fixture.settle=async()=>{await new Promise(resolve=>setTimeout(resolve,180));};
  fixture.frame=async(id,url)=>{const frame=document.createElement('iframe');frame.id=id;frame.title=id;frame.src=url;const loaded=new Promise(resolve=>frame.onload=resolve);document.getElementById('views').append(frame);await loaded;await fixture.settle();return frame;};
})();
