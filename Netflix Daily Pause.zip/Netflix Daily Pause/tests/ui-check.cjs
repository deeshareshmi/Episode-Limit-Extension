// Uses an isolated headless Chrome profile and the local fixture server.
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),{spawn}=require('node:child_process');
const createServer=require('./ui-server.cjs');
(async()=>{
  const parent=path.resolve(os.tmpdir()),profile=fs.mkdtempSync(path.join(parent,'daily-pause-ui-')),server=createServer();
  try{
    await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
    const browser=process.argv[2]||'C:/Program Files/Google/Chrome/Application/chrome.exe';
    const preview=process.argv[3],screenshot=process.argv[4];
    const url=`http://127.0.0.1:${server.address().port}/tests/ui.html${preview?'?preview='+encodeURIComponent(preview):''}`;
    const args=['--headless','--disable-gpu','--no-first-run','--no-default-browser-check',`--user-data-dir=${profile}`,'--virtual-time-budget=20000',`--window-size=${preview==='mobile'?'390,1000':'1200,1100'}`,'--dump-dom'];
    if(screenshot)args.push(`--screenshot=${path.resolve(screenshot)}`);args.push(url);
    const result=await new Promise((resolve,reject)=>{
      const child=spawn(browser,args,{windowsHide:true});let stdout='',stderr='';
      const timeout=setTimeout(()=>{child.kill();reject(Error('UI browser check timed out'));},45000);
      child.stdout.on('data',data=>stdout+=data);child.stderr.on('data',data=>stderr+=data);
      child.on('error',error=>{clearTimeout(timeout);reject(error);});child.on('close',code=>{clearTimeout(timeout);resolve({code,stdout,stderr});});
    });
    console.log(result.stdout.match(/<pre id="results">([\s\S]*?)<\/pre>/)?.[1]||result.stderr.slice(-2000));
    if(!preview&&!result.stdout.includes('data-tests="passed"'))process.exitCode=1;
  }finally{
    server.closeAllConnections();await new Promise(resolve=>server.close(resolve));
    if(path.resolve(profile).startsWith(parent+path.sep)&&path.basename(profile).startsWith('daily-pause-ui-'))fs.rmSync(profile,{recursive:true,force:true,maxRetries:3});
  }
})().catch(error=>{console.error(error);process.exitCode=1;});
