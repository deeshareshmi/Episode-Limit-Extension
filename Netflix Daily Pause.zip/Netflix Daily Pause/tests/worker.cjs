// Actual worker + site-lock code, with Chrome persistence, rules and alarms mocked.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.join(__dirname,'..'),copy=x=>JSON.parse(JSON.stringify(x));
let database={},listener,clock=new Date(2026,8,30,12).getTime(),rules=[],alarms={},handlers={},opened=[];
class ClockDate extends Date{static now(){return clock;}}
function boot(){
  const context=vm.createContext({console,URL,Date:ClockDate,chrome:{
    runtime:{getURL:path=>`chrome-extension://fixture/${path}`,onMessage:{addListener:fn=>listener=fn},onStartup:{addListener:fn=>handlers.startup=fn},onInstalled:{addListener:fn=>handlers.installed=fn}},
    tabs:{async create(options){opened.push(options);}},
    storage:{local:{async get(key){return database[key]?{[key]:copy(database[key])}:{};},async set(values){Object.assign(database,copy(values));}}},
    declarativeNetRequest:{async getDynamicRules(){return copy(rules);},async updateDynamicRules({removeRuleIds,addRules}){rules=rules.filter(r=>!removeRuleIds.includes(r.id)).concat(copy(addRules));}},
    alarms:{onAlarm:{addListener:fn=>handlers.alarm=fn},async get(name){return alarms[name];},async create(name,{when}){alarms[name]={name,scheduledTime:when};},async clear(name){delete alarms[name];}}
  }});
  context.importScripts=(...names)=>{for(const name of names)vm.runInContext(fs.readFileSync(path.join(root,name),'utf8'),context);};
  vm.runInContext(fs.readFileSync(path.join(root,'background.js'),'utf8'),context);
}
const send=(message,tab=1)=>new Promise(resolve=>listener(message,{tab:{id:tab},url:'https://www.netflix.com/watch/1'},resolve));
const assert=(value,message)=>{if(!value)throw Error(message);};
let passes=0;const pass=message=>{passes++;console.log(`PASS ${message}`);};
(async()=>{
  boot();const item={kind:'episode',id:'1',title:'Mock Show',season:1,episode:1};
  await Promise.all(Array.from({length:20},(_,i)=>send({type:'tick',session:'mock',seq:Math.floor(i/2)+1,ms:1000,item,watchId:'1',attempt:true},i%2+1)));
  let r=await send({type:'get'});assert(r.today.ms===20000,'Concurrent writes lost time');pass('Worker serializes concurrent samples');
  await send({type:'tick',session:'mock',seq:10,ms:1000,item,watchId:'1'});r=await send({type:'get'});assert(r.today.ms===20000,'Retry counted twice');pass('Retry deduplication persists');
  boot();r=await send({type:'get'});assert(r.today.ms===20000&&rules.length===0,'Restart corrupted state');pass('Restart restores ordinary state without a block rule');
  const invalid=await send({type:'settings',settings:{episodes:0,minutes:0}});assert(invalid.error,'Invalid settings accepted');r=await send({type:'get'});assert(r.today.ms===20000,'Queue broke');pass('Invalid settings do not break the worker');
  await send({type:'settings',settings:{episodes:1,minutes:90,reason:'Sleep on time',diagnostic:true}});
  await send({type:'diagnostic',observation:{classification:'unknown'}});assert(database.diagnostic.classification==='unknown','Diagnostic lost');pass('Settings and diagnostics remain local');
  for(let i=11;i<=66;i++)await send({type:'tick',session:'mock',seq:i,ms:5000,item,watchId:'1',attempt:true});
  r=await send({type:'navigation',session:'mock',targetId:'2',item,watchId:'1'});assert(r.blocked&&r.friction.waitMs===60000,'Wrong first break');
  let request={type:'choice',choice:'episode',session:'mock',date:r.date,revision:r.revision,item,context:r.context};
  r=await send(request);assert(r.blocked&&r.today.extensionsUsed===0,'Early concession allowed');clock+=10000;boot();r=await send({type:'get'});assert(r.friction.waitMs===50000,'Restart reset break');clock+=50000;r=await send(request);assert(!r.blocked&&r.today.extensionsUsed===1,'First concession failed');pass('First 60-second break is enforced across restart');
  r=await send({type:'tick',session:'mock',seq:67,ms:0,item:{kind:'unknown'},watchId:'2',attempt:true});assert(!r.blocked&&r.today.allowance.id==='2'&&!r.today.episodes['2'],'Unknown title could not continue safely');pass('Unknown title uses a watch-ID allowance without invented logs');
  r=await send({type:'tick',session:'mock',seq:68,ms:0,item:{kind:'unknown'},watchId:'2',ended:true});assert(r.blocked&&r.friction.waitMs===300000,'No five-minute second break');
  clock+=300000;request={type:'choice',choice:'episode',date:r.date,revision:r.revision,item:r.item,context:r.context,reason:'Please continue'};
  r=await send(request);assert(r.blocked,'Wrong phrase accepted');r=await send({...request,reason:'I want to watch one more episode'});assert(!r.blocked&&r.today.extensionsUsed===2,'Exact phrase rejected');pass('Second concession needs five minutes and the exact phrase');
  await send({type:'tick',session:'mock',seq:69,ms:0,item:{kind:'unknown'},watchId:'3',attempt:true});
  r=await send({type:'tick',session:'mock',seq:70,ms:0,item:{kind:'unknown'},watchId:'3',ended:true});
  assert(r.today.stopped&&rules.length===1,'Final concession did not install site lock');
  assert(rules[0].action.type==='block'&&rules[0].condition.requestDomains.join()==='netflix.com'&&rules[0].condition.resourceTypes.join()==='main_frame','Rule is not Netflix-only top-level blocking');pass('Final extra episode automatically installs the Netflix navigation block');
  r=await send({type:'get'},2);assert(r.blocked&&r.today.stopped,'New tab not locked');
  await send({type:'settings',settings:{episodes:100,minutes:1440,reason:'Changed',diagnostic:true}});r=await send({type:'get'});assert(r.blocked&&rules.length===1,'Settings removed the lock');pass('New tabs and settings changes cannot concede after final lockout');
  alarms={};boot();r=await send({type:'get'});assert(r.blocked&&rules.length===1&&alarms['netflix-daily-unlock'],'Restart lost the rule or failed to restore the alarm');pass('Persistent site rule and missing midnight alarm survive worker restart');
  clock=alarms['netflix-daily-unlock'].scheduledTime;handlers.alarm({name:'netflix-daily-unlock'});r=await send({type:'get'});
  assert(!r.blocked&&rules.length===0&&r.today.extensionsUsed===0&&!alarms['netflix-daily-unlock'],'Midnight did not release the lock');pass('Midnight alarm removes the rule and resets daily concessions');
  r=await send({type:'choice',choice:'stop',date:r.date,revision:r.revision,context:{mode:'summary'}});assert(r.blocked&&rules.length===1,'Stop does not site-lock');pass('Stop for today also installs the navigation block');
  const preserved=copy(database.state);
  handlers.installed({reason:'update'});handlers.startup();await send({type:'get'});
  assert(!opened.length&&database.state.days[r.date].stopped,'Update reopened welcome or reset lockout');
  handlers.installed({reason:'install'});await send({type:'get'});
  assert(opened.length===1&&opened[0].url==='chrome-extension://fixture/options.html#welcome','First install did not open packaged welcome');
  boot();await send({type:'get'});assert(opened.length===1,'Worker restart reopened welcome');pass('Welcome opens only on first installation; existing settings and lock survive');
  await Promise.all([send({type:'settings',settings:{episodes:3}}),send({type:'settings',settings:{minutes:45}})]);
  r=await send({type:'get'});assert(r.settings.episodes===3&&r.settings.minutes===45&&r.settings.reason===preserved.settings.reason&&r.settings.diagnostic,'Partial saves lost unrelated fields');
  assert(r.today.stopped&&rules.length===1,'Partial saves cleared restrictions');
  await Promise.all([send({type:'settings',settings:{episodes:4}}),send({type:'settings',settings:{episodes:5}})]);
  r=await send({type:'get'});assert(r.settings.episodes===5,'Last save did not win');pass('Concurrent partial saves merge; same-field last save wins without unlocking');
  for(const settings of [null,[],{minutes:0},{episodes:101},{episodes:1.5}])assert((await send({type:'settings',settings})).error,'Invalid partial save accepted');
  const before=JSON.stringify(database);const history=await send({type:'history'});
  assert(history.days.length===2&&history.days[1].count===1&&history.days[1].ms===300000,'Wrong history totals');
  assert(JSON.stringify(database)===before&&!('sessions' in history)&&!('allowance' in history.days[0]),'History request changed state or exposed policy bookkeeping');
  pass('History reports existing logs and playback totals without writing state');
  database.state.days['2026-09-29']={ms:180000,episodes:{short:{id:'short',title:'Partial',ms:30000}},stopped:false};
  const partial=(await send({type:'history'})).days.find(d=>d.date==='2026-09-29');
  assert(partial.count===0&&partial.episodes.length===1&&partial.ms===180000,'Partial episode or movie minutes misrepresented');
  for(let i=1;i<=100;i++){const date=new Date(2026,0,i).toISOString().slice(0,10);database.state.days[date]={ms:0,episodes:{}};}
  assert((await send({type:'history'})).days.length===90,'History exceeded retained view');pass('History handles partial episodes, unlogged minutes and the 90-day view');
  console.log(`${passes}/${passes} worker checks passed`);
})().catch(error=>{console.error(error);process.exitCode=1;});
