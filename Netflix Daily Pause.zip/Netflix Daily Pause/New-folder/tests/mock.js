let mock, number;
const $=id=>document.getElementById(id);
function render(){
  const r=mock.result;
  $('screen').textContent=mock.item.kind==='episode'?`Mock Show · S1 E${number}`:'Mock movie';
  $('state').textContent=JSON.stringify({date:r.date,playing:mock.playing,position:mock.position,minutes:r.today.ms/60000,episodes:r.count,override:r.today.override,log:r.today.episodes},null,2);
  $('prompt').hidden=!r.blocked;
  $('summary').textContent=`Limit: ${r.settings.episodes} episodes / ${r.settings.minutes} minutes. Watched: ${r.count} episodes / ${(r.today.ms/60000).toFixed(1)} minutes. ${r.today.stopped?'Stopped until tomorrow.':''}`;
  $('extra-episode').hidden=mock.item.kind!=='episode'||r.today.stopped;
  $('extra-time').hidden=r.today.stopped;
}
function reset(){mock=new MockPlayer();number=1;mock.state.settings.episodes=1;mock.state.settings.minutes=2;render();}
function advance(seconds){for(let i=0;i<seconds;i++){if(mock.result.blocked){mock.pause();break;}mock.step();}render();}
$('play').onclick=()=>{if(!mock.result.blocked)mock.play();render();};
$('pause').onclick=()=>{mock.pause();render();};
$('advance').onclick=()=>{if(!mock.result.blocked)mock.play();advance(60);};
$('next').onclick=()=>{mock.next(String(++number));if(mock.result.blocked)mock.pause();render();};
$('movie').onclick=()=>{mock.item={kind:'movie'};mock.key='movie';mock.position=0;mock.sample();render();};
$('seek').onclick=()=>{mock.seeking=true;mock.position+=600;mock.sample();mock.seeking=false;mock.sample();render();};
$('midnight').onclick=()=>{const date=new Date(mock.now);date.setHours(23,59,59,500);mock.now=date.getTime();mock.sampler.reset();mock.sample();mock.step();render();};
$('reset').onclick=reset;
for(const [id,choice] of [['stop','stop'],['extra-episode','episode'],['extra-time','time']]) $(id).onclick=()=>{mock.choose(choice);if(!mock.result.blocked)mock.play();render();};
reset();setInterval(()=>advance(1),1000);
