(function () {
  'use strict';
  const E = LimitEngine, results = [];
  const episode = id => ({ kind: 'episode', id, title: 'Mock Show', season: 1, episode: Number(id), episodeTitle: `Chapter ${id}` });
  const assert = (value, message = 'Assertion failed') => { if (!value) throw new Error(message); };
  const test = (name, fn) => { try { fn(); results.push({ name, pass: true }); } catch (e) { results.push({ name, pass: false, error: e.message }); } };
  class MockPlayer {
    constructor(state = E.fresh(), tab = 'tab1', now = new Date(2026,8,27,12).getTime()) {
      this.state = state; this.tab = tab; this.now = now; this.seq = 0; this.item = episode('1'); this.key = '1';
      this.position = 0; this.playing = false; this.seeking = false; this.rate = 1; this.eligible = true; this.sampler = new PlaybackSampler(); this.sample();
    }
    sample() {
      const ms = this.sampler.sample({ key:this.key, now:this.now, position:this.position, playing:this.playing, seeking:this.seeking, rate:this.rate, eligible:this.eligible });
      return this.result = E.tick(this.state,this.tab,{ seq:++this.seq, ms, item:this.item },this.now);
    }
    play() { this.playing = true; this.sample(); }
    pause() { this.playing = false; this.sample(); }
    step(seconds=1) { for(let i=0;i<seconds;i++) { this.now+=1000; if(this.playing&&!this.seeking) this.position+=this.rate; this.sample(); } return this.result; }
    next(id) { this.key=id; this.item=episode(id); this.position=0; return this.sample(); }
    choose(choice,ended=false) { const r=this.result; return this.result=E.choose(this.state,{ choice, item:this.item, ended, date:r.date, revision:r.revision },this.now); }
  }
  test('Paused and open tabs record no time; meaningful playback counts at 60 seconds', () => {
    const p=new MockPlayer(); p.step(100); assert(p.result.today.ms===0); p.play(); p.step(59); assert(p.result.count===0); p.step(); assert(p.result.count===1); p.pause(); p.step(100); assert(p.result.today.ms===60000);
  });
  test('Stopping just before credits still counts; resume and replay do not duplicate', () => {
    const p=new MockPlayer(); p.play(); p.step(119); p.pause(); p.step(30); p.play(); p.step(80); assert(p.result.count===1); assert(Object.keys(p.result.today.episodes).length===1); assert(p.result.today.ms===199000);
  });
  for (const mode of ['autoplay','manual Next Episode']) test(`${mode}: episode allowance pauses before a further episode`, () => {
    const p=new MockPlayer(); p.state.settings.episodes=1; p.play(); p.step(60); assert(p.result.blocked); p.choose('episode'); assert(!p.result.blocked); p.step(60); assert(!p.result.blocked,'No immediate repeated prompt'); p.next('2'); assert(p.result.blocked); assert(!p.result.today.episodes['2'],'Gate runs before episode 2 has played');
  });
  test('An allowance selected at the ended event binds the NEXT episode only', () => {
    const p=new MockPlayer(); p.state.settings.episodes=1; p.play(); p.step(60); p.choose('episode',true); p.sample(); assert(!p.result.blocked); p.next('2'); assert(!p.result.blocked); p.next('3'); assert(p.result.blocked);
  });
  test('30 minute override ignores both base limits, then expires on playback time', () => {
    const p=new MockPlayer(); p.state.settings.minutes=1; p.state.settings.episodes=1; p.play(); p.step(60); p.choose('time'); assert(!p.result.blocked); p.step(900); p.pause(); p.step(600); assert(!p.result.blocked); p.play(); p.next('2'); p.step(899); assert(!p.result.blocked); p.step(1); assert(p.result.blocked && p.result.cause==='time-override');
  });
  test('Overrides replace each other instead of stacking', () => {
    const p=new MockPlayer(); p.state.settings.episodes=1; p.play(); p.step(60); p.choose('time'); const until=p.result.today.override.until; p.choose('episode'); assert(p.result.today.override.type==='episode'); p.next('2'); assert(p.result.blocked); p.choose('time'); assert(p.result.today.override.type==='time' && p.result.today.override.until===until);
  });
  test('A partial movie and unknown metadata add minutes, never episodes', () => {
    const p=new MockPlayer(); p.item={ kind:'movie' }; p.state.settings.minutes=1; p.play(); p.step(60); assert(p.result.count===0 && p.result.today.ms===60000 && p.result.blocked); p.choose('episode'); assert(p.result.blocked && !p.result.today.override); p.choose('time'); assert(!p.result.blocked); p.item={kind:'unknown'}; p.step(60); assert(p.result.count===0 && Object.keys(p.result.today.episodes).length===0);
  });
  test('Seeking, stalled media, previews, and discontinuities do not add playback', () => {
    const p=new MockPlayer(); p.play(); p.step(10); p.seeking=true; p.position+=900; p.sample(); p.step(20); p.seeking=false; p.sample(); assert(p.result.today.ms===10000); p.now+=1000; p.sample(); assert(p.result.today.ms===10000); p.position+=900; p.now+=1000; p.sample(); assert(p.result.today.ms===10000); p.eligible=false; p.step(20); assert(p.result.today.ms===10000);
  });
  test('Playback rate counts wall time, not media duration', () => {
    const p=new MockPlayer(); p.rate=2; p.play(); p.step(60); assert(p.result.today.ms===60000 && p.position===120);
  });
  test('Two tabs share totals and deduplicate the same episode; retry is idempotent', () => {
    const state=E.fresh(), a=new MockPlayer(state,'a'), b=new MockPlayer(state,'b'); a.play(); b.play(); a.step(30); b.step(30); assert(b.result.count===1 && b.result.today.ms===60000); E.tick(state,'b',{ seq:b.seq, ms:1000, item:b.item },b.now); assert(b.result.today.ms===60000); a.state.settings.minutes=1; assert(E.verdict(state,a.item,a.now).blocked);
  });
  test('Stop for today is shared, persists through serialization, clears at midnight', () => {
    const p=new MockPlayer(); p.choose('stop'); const restored=JSON.parse(JSON.stringify(p.state)); assert(E.verdict(restored,episode('2'),p.now).blocked); p.choose('time'); assert(p.result.today.stopped); const tomorrow=new Date(p.now); tomorrow.setDate(tomorrow.getDate()+1); assert(!E.verdict(restored,episode('1'),tomorrow.getTime()).blocked);
  });
  test('A sample crossing local midnight splits both totals and episode logs', () => {
    const now=new Date(2026,8,27,23,59,59,500).getTime(), p=new MockPlayer(undefined,'a',now); p.play(); p.step(); const keys=Object.keys(p.state.days).sort(); assert(keys.length===2); assert(p.state.days[keys[0]].ms===500 && p.state.days[keys[1]].ms===500); assert(p.state.days[keys[0]].episodes['1'].ms===500 && p.result.count===0);
  });
  test('Allowances reset at midnight and stale dialogs cannot extend them', () => {
    const p=new MockPlayer(); p.choose('time'); const old={ date:p.result.date, revision:p.result.revision, choice:'time', item:p.item }; p.now+=86400000; const result=E.choose(p.state,old,p.now); assert(!result.today.override && result.today.ms===0);
  });
  test('Two simultaneous dialog choices cannot stack allowances', () => {
    const p=new MockPlayer(); const request={ date:p.result.date, revision:p.result.revision, choice:'time', item:p.item }; E.choose(p.state,request,p.now); const revision=p.result.today.revision; E.choose(p.state,request,p.now); assert(p.result.today.revision===revision);
  });
  test('Detector requires episode evidence and rejects previews', () => {
    const classify=NetflixDetection.classify;
    assert(classify({watchId:'1',title:'Show',detail:'Show S1:E2 Chapter',preview:false}).kind==='episode');
    assert(classify({watchId:'1',title:'Movie',detail:'Movie',preview:false}).kind==='unknown');
    assert(classify({watchId:'1',title:'Show',detail:'S1:E2',preview:true}).kind==='preview');
    assert(classify({watchId:null,title:'Show',detail:'S1:E2',preview:false}).kind==='unknown');
  });
  test('Detector suppresses stale SPA titles and preserves hidden-control metadata', () => {
    let text='Show S1:E1 First';
    const metadata={ get textContent(){return text;}, querySelector:()=>({textContent:'Show'}) };
    const player={ querySelectorAll:()=>[{clientWidth:100,clientHeight:100}], querySelector:s=>s.includes('video-title') ? (text ? metadata:null) : null };
    const doc={querySelector:()=>player}, loc={pathname:'/watch/1'}, d=new NetflixDetection.NetflixDetector();
    d.observe(doc,loc); assert(d.observe(doc,loc).item.kind==='episode'); loc.pathname='/watch/2'; assert(d.observe(doc,loc).item.kind==='unknown'); assert(d.observe(doc,loc).item.kind==='unknown'); text='Show S1:E2 Second'; d.observe(doc,loc); assert(d.observe(doc,loc).item.id==='2'); text=''; assert(d.observe(doc,loc).item.id==='2');
  });
  globalThis.MockPlayer=MockPlayer;
  globalThis.testResults=results;
  if (typeof document !== 'undefined') {
    const output=document.getElementById('test-results');
    output.textContent=results.map(r=>`${r.pass?'PASS':'FAIL'} ${r.name}${r.error?': '+r.error:''}`).join('\n');
    document.documentElement.dataset.tests=results.every(r=>r.pass)?'passed':'failed';
  }
})();
