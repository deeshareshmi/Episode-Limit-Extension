// Integration checks for actual background.js with mocked Chrome message/storage APIs.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.join(__dirname,'..');
let database={},listener,writes=0;
const copy=x=>JSON.parse(JSON.stringify(x));
function boot(){
  const context=vm.createContext({console,Date,chrome:{runtime:{onMessage:{addListener(fn){listener=fn;}}},storage:{local:{
    async get(key){await new Promise(r=>setTimeout(r,1));return database[key]?{[key]:copy(database[key])}:{};},
    async set(values){await new Promise(r=>setTimeout(r,1));Object.assign(database,copy(values));writes++;}
  }}}});
  context.importScripts=name=>vm.runInContext(fs.readFileSync(path.join(root,name),'utf8'),context);
  vm.runInContext(fs.readFileSync(path.join(root,'background.js'),'utf8'),context);
}
const send=(message,tab=1)=>new Promise(resolve=>listener(message,{tab:{id:tab},url:'https://www.netflix.com/watch/1'},resolve));
const assert=(value,message)=>{if(!value)throw Error(message);};
(async()=>{
  boot();
  const item={kind:'episode',id:'1',title:'Mock Show',season:1,episode:1};
  await Promise.all(Array.from({length:20},(_,i)=>send({type:'tick',session:'mock',seq:Math.floor(i/2)+1,ms:1000,item},i%2+1)));
  let r=await send({type:'get'});assert(r.today.ms===20000,'Concurrent writes lost time');console.log('PASS Worker serializes concurrent messages from two tabs');
  await send({type:'tick',session:'mock',seq:10,ms:1000,item},2);
  r=await send({type:'get'});assert(r.today.ms===20000,'Duplicate heartbeat counted');console.log('PASS Worker deduplicates retries');
  boot();r=await send({type:'get'});assert(r.today.ms===20000,'Restart lost state');console.log('PASS Worker restart restores storage');
  let invalid=await send({type:'settings',settings:{episodes:0,minutes:0}});assert(invalid.error,'Invalid settings accepted');
  r=await send({type:'get'});assert(r.today.ms===20000,'Rejected message broke queue');console.log('PASS Invalid settings rejected without breaking message queue');
  await send({type:'settings',settings:{episodes:1,minutes:1,reason:'Rest',diagnostic:true}});
  await send({type:'diagnostic',observation:{classification:'unknown'}});assert(database.diagnostic.classification==='unknown','Diagnostic not saved');console.log('PASS Settings and diagnostic observations persist locally');
  r=await send({type:'get'});await send({type:'choice',choice:'stop',date:r.date,revision:r.revision,item});boot();r=await send({type:'get'});assert(r.blocked && r.today.stopped,'Stop did not persist');console.log('PASS Stop survives worker restart');
  console.log('6/6 worker checks passed');
})().catch(error=>{console.error(error);process.exitCode=1;});
