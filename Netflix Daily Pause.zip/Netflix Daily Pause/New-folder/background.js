importScripts('engine.js');
let queue = Promise.resolve();
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (!['tick','get','settings','choice','diagnostic'].includes(message?.type)) return false;
  queue = queue.catch(() => {}).then(async () => {
    const state = (await chrome.storage.local.get('state')).state || LimitEngine.fresh();
    const now = Date.now();
    let result;
    if (message.type === 'tick') {
      if (!sender.tab || !sender.url?.startsWith('https://www.netflix.com/')) throw new Error('Netflix tab required');
      result = LimitEngine.tick(state, `${sender.tab.id}:${message.session}`, message, now);
    } else if (message.type === 'choice') result = LimitEngine.choose(state, message, now);
    else if (message.type === 'settings') {
      const s = message.settings;
      if (!Number.isInteger(s.episodes) || s.episodes < 1 || s.episodes > 100 || !Number.isInteger(s.minutes) || s.minutes < 1 || s.minutes > 1440) throw new Error('Enter 1–100 episodes and 1–1440 minutes.');
      state.settings = { episodes: s.episodes, minutes: s.minutes, reason: String(s.reason || '').trim().slice(0,240), diagnostic: !!s.diagnostic };
      const d = LimitEngine.day(state,now); d.override = null; d.revision++;
      result = LimitEngine.verdict(state,null,now);
    } else if (message.type === 'diagnostic') {
      if (state.settings.diagnostic) await chrome.storage.local.set({ diagnostic: { ...message.observation, observedAt: new Date(now).toISOString(), tabId: sender.tab?.id } });
      return { ok: true };
    } else result = LimitEngine.verdict(state,null,now);
    await chrome.storage.local.set({ state });
    return result;
  });
  queue.then(reply, error => reply({ error: error.message }));
  return true;
});
