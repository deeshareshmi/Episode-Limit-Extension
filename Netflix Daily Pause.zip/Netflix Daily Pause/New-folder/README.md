# Netflix Daily Pause — local Manifest V3 MVP

Plain JavaScript; no build, dependencies, account, backend, telemetry, remote scripts, or Netflix private APIs. Settings, playback totals, episode logs, and allowances use `chrome.storage.local`. The only API permission is `storage`; the content script runs only on `https://www.netflix.com/*`. No tabs, history, scripting, or network interception permissions.

**Live Netflix detection has NOT been tested.** No authenticated Netflix player was accessible during development. The in-app browser connection failed during setup. Automated tests cover the production tracking/state logic and mocked DOM/Chrome APIs; they do not establish that Netflix's current DOM matches the detector or that its real player accepts pause/resume commands. Visual popup/fullscreen checks and real Chrome extension integration remain manual.

## Load the extension in Chrome

1. Keep `manifest.json`, the JavaScript files, `popup.html`, and `popup.css` together in this folder. No build command is needed.
2. Open Google Chrome and enter `chrome://extensions` in the address bar.
3. Turn on **Developer mode** (upper right).
4. Click **Load unpacked**. Choose this folder: `C:\Users\deesha.reshmi\Desktop\Prep\New folder` — the folder containing `manifest.json`, not `tests`.
5. Open Chrome's Extensions menu (puzzle icon), then pin **Netflix Daily Pause**.
6. Open the popup, set daily limits and optionally a one-sentence reason, then click **Save settings**. Defaults are 2 episodes and 90 minutes.
7. Open `https://www.netflix.com`, sign in yourself, and open a full episode. Reload any Netflix tabs that were open before installation.
8. After editing these files, click **Reload** on the extension card in `chrome://extensions`, then reload Netflix tabs. An old content script can lose its extension connection; it pauses playback and reports a console warning until reloaded.

## Behavior and deliberate MVP choices

- A confidently identified episode counts after **60 seconds of actual playback**, accumulated across resumes and tabs on the same local day. Its log entry appears before 60 seconds but is labeled uncounted. Credits/completion are not required. Rewatching the same Netflix watch ID adds minutes without another daily episode count.
- A new local day starts a new daily count. The same episode spanning midnight can count on each day if it receives 60 seconds on each. Samples are split at local midnight; settings persist and allowances/Stop expire. Clock/timezone changes follow the machine's local date.
- Time is elapsed playback time, not the media position or time with a tab open. Pauses, seeking, stalled media, recognized previews and pages outside `/watch/<id>` do not accumulate. At 2x speed, one real minute counts as one minute.
- Movies and unidentified videos contribute minutes only. Missing episode labels are **not** treated as proof that a title is a movie. No fabricated episode log entries. Time accumulated while identity is unknown remains only in total minutes; it is not assigned retroactively.
- Limits apply immediately when **either** daily threshold is reached, including in the middle of an episode. The prompt includes configured limits, today's totals and your reason.
- **Watch one more episode** permits the current unfinished episode until a different episode starts. If selected after the current video has ended, it permits the next identifiable episode. It temporarily bypasses both daily thresholds. The next different episode is gated; unknown identity during this allowance pauses conservatively and offers the time option instead. The choice is unavailable for movies/unidentified videos.
- **Continue for 30 more minutes** permits 30 additional aggregate playback minutes, across episode transitions, temporarily bypassing both daily thresholds. Paused time does not use the allowance. A new prompt appears when it expires.
- These are distinct, mutually exclusive temporary allowances, not increases to the saved daily limits. Choosing a new allowance replaces the old one. Saving settings clears allowances. **Stop for today** remains locked until local midnight, including after reload/restart or a settings edit. It does not automatically restart playback at midnight.
- Two tabs share one state and stop/allowance policy. If both play concurrently, both streams' playback time is added (two simultaneous minutes count as two minutes); episode IDs remain deduplicated. An episode allowance applies to one shared episode ID. Worker messages serialize storage updates; stale duplicate samples and duplicate allowance decisions are ignored.
- Logs retain the latest 90 recorded days locally; the popup shows today. Chrome's extension **Remove** action clears the extension's local data. This is a personal reminder, not tamper-proof parental control.

## Timing and detection limitations

`detector.js` contains all Netflix selectors, metadata classification, watch-ID transitions, stability checks, and same-ID metadata caching. Change this module when Netflix changes markup.

The current detector looks for `.watch-video` / `[data-uia="watch-video"]`, then the largest video inside it, and title metadata in `[data-uia="video-title"]` / `.video-title` with a title in `h4`/`h3`. Only explicit English `S1:E2` / `Season 1 Episode 2` style metadata is recognized. Localized labels or different layouts fall back to minutes only. It does not read Netflix's private JavaScript state, request metadata, infer episode numbers from duration, or inspect DRM media.

Browse previews are excluded by the watch-page/main-player requirement. Recognizable trailer/teaser/preview labels and explicit preview-player markers are excluded. Unlabeled previews, ads within the main video, unusual embedded players, and title text containing those words can be misclassified. Verify these on your Netflix account; exclusion cannot be guaranteed.

Transitions are detected by Netflix watch URL, plus metadata freshness checks to avoid attaching the previous title to a new URL. Hidden controls reuse metadata only for that same watch ID. A transition without a URL change, stale initial metadata on a page opened mid-transition, or player element replacement can evade this heuristic. The extension uses playback events plus a one-second poll: a URL transition observed by a play event is gated immediately; one discovered by polling may show up to roughly a second of the new video before pausing. Browser throttling or main-thread stalls can delay this further. This MVP cannot promise frame-perfect prevention before autoplay on an untested proprietary player.

Samples over five seconds or with suspicious position jumps are discarded to avoid counting sleep, stalls or seeks. Event boundaries, busy message handling, buffering and throttling can undercount small intervals. Abrupt tab closure can lose the final unsent interval. Samples are assigned using worker receipt time, so a delayed message near midnight may shift a small interval. No page visibility requirement: background playback counts while the video advances.

## Diagnostics

1. In the popup, enable **detector diagnostics** and save.
2. Open or reload a Netflix watch page and briefly reveal its player controls so title metadata is available.
3. Reopen the popup and expand **Latest detector observation**. It refreshes about every five seconds, even if the expected player is missing.
4. Check `watchId`, `mainPlayerFound`, `videoFound`, `title`, `detail`, `classification`, `transition`, `waitingForFreshMetadata`, playback status, sample duration and selectors. The timestamp/tab ID identify the latest tab observation. Observations stay local; only the latest one is retained.
5. If `classification` remains `unknown`, verify the DOM selectors and explicit season/episode labels in Chrome DevTools. Minutes should still count if the main player is found. If `mainPlayerFound` or `videoFound` is false, even main-video tracking needs a selector update; the extension deliberately does not choose an arbitrary preview video.

## Automated tests and mock player

With Node.js 18 or later installed, open a terminal in this folder:

```sh
node tests/run.cjs
node tests/worker.cjs
```

No `npm install` is needed. Verified during development: **17/17 logic/detector checks and 6/6 worker integration checks passed**. JavaScript syntax checks also passed. The tests use production `engine.js`, `tracker.js`, `detector.js` and `background.js`, with a deterministic fake video clock and mocked DOM/Chrome APIs. Autoplay and manual Next are simulated transition inputs, not exercised Netflix buttons.

The cases cover: autoplay, manual Next, stopping before credits, resuming/rewatching an episode, partial movies, unknown identity, seeking, stalled/paused media, previews, playback rate, concurrent tabs, repeated messages, both allowances, stale dialog decisions, Stop persistence, worker restart, and midnight splitting/reset.

For the interactive mock, double-click `tests/mock.html` to open it in Chrome. The extension need not be loaded. It runs the same 17 checks and provides Play, Pause, Next Episode, Movie, Seek, Midnight, Reset, and an accelerated **Play 60 seconds** button. This mock is a simulation UI, not the injected Netflix overlay. All mock data is in memory and disappears on reload. The extension has no file-URL access requirement.

## Manual Netflix acceptance checklist — still required

Use an English Netflix profile first. Set **1 episode / 1 minute**, enable diagnostics, and use a disposable test state. To reset all extension data between independent scenarios, open the extension service worker's **Inspect** link in `chrome://extensions` and run `chrome.storage.local.clear()`, then reload Netflix tabs. This deletes this extension's settings/logs only. Do not use this reset if you want to retain your history.

| Check | Steps and expected result |
| --- | --- |
| Identify real episode | Reveal controls on a full episode; diagnostic title/season/episode must match the actual episode. Wait for stable metadata. Popup log must match. |
| Episode threshold / stop before end | Use high minute limit, episode limit 1. Play 60 seconds; pause prompt must appear, long before credits. Reason and totals must be correct. |
| Resume same episode | Grant episode allowance, play more, pause, close/reopen that watch URL. The same log entry gains time; count stays 1. |
| Autoplay | Grant episode allowance; seek near the end (seek distance must not count), let it autoplay. Verify a new prompt at the transition; measure any late pause. Check for old-title/new-ID mix-ups. |
| Manual Next | Repeat with Netflix's Next Episode button. The allowance must not carry into a further episode. Also test selecting the allowance when the video has ended. |
| Time allowance | Reach a limit, choose 30 minutes. No immediate prompt; pause for several minutes and verify allowance is unchanged. Resume through episode transitions. Prompt must return after 30 actual playback minutes. |
| Partial movie / unknown | Play part of a film for a minute. Minutes grow, episode count/log do not. Prompt offers Stop and the time continuation only. Repeat when metadata is intentionally unavailable. |
| Pause, buffer, seek | Note totals; pause, scrub far forward/back, and resume. Only actual playback should add time. Test 2x speed and a temporary network stall. |
| Previews / trailers | Hover browse tiles and open a clearly labeled trailer. Neither should count if recognized. Inspect diagnostics for account-specific unlabeled previews or ads. |
| Two tabs | Play the same episode in two tabs; verify shared summed minutes and one episode count. Reach a limit or choose Stop in one tab; the other should pause on its next heartbeat. Test different episodes with a shared episode allowance. |
| Midnight | Prefer the deterministic mock for clock control. On Netflix, leave a session across actual local midnight: totals/log change day, Stop/overrides expire. Playback never auto-starts just because the date changes. |
| Real UI and persistence | Verify popup layout, keyboard navigation, readable reason text, injected prompt in windowed/fullscreen modes, and pause enforcement after repeated Play attempts. Restart Chrome and confirm state persists. |

## Files

- `engine.js`: daily ledger, thresholds, allowances, deduplication, midnight splitting.
- `tracker.js`: playback sampling independent of Netflix.
- `detector.js`: isolated Netflix DOM assumptions and transitions.
- `background.js`: serialized messages and persistent local state.
- `content.js`: event sampling, pause enforcement, fullscreen-aware isolated prompt.
- `popup.*`: settings, totals, daily episode log and diagnostic viewer.
- `tests/`: deterministic tests, mocked worker integration and interactive simulation.

Manifest and messaging structure were checked against Chrome's official [Manifest format](https://developer.chrome.com/docs/extensions/reference/manifest), [content scripts](https://developer.chrome.com/docs/extensions/develop/concepts/content-scripts) and [message passing](https://developer.chrome.com/docs/extensions/develop/concepts/messaging) documentation.
