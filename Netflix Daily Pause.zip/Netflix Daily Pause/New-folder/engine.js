/* Pure state machine, shared by the worker and deterministic mock tests. */
(function (g) {
  'use strict';
  const MEANINGFUL_MS = 60000;
  const dayKey = time => {
    const d = new Date(time);
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  };
  const fresh = () => ({ settings: { episodes: 2, minutes: 90, reason: '', diagnostic: false }, days: {}, sessions: {} });
  function day(state, now) {
    const key = dayKey(now);
    return state.days[key] ||= { ms: 0, episodes: {}, stopped: false, override: null, revision: 0 };
  }
  const count = d => Object.values(d.episodes).filter(e => e.ms >= MEANINGFUL_MS).length;
  function verdict(state, item, now) {
    const d = day(state, now), s = state.settings;
    let blocked = d.stopped, cause = d.stopped ? 'stopped' : '';
    if (!blocked && d.override?.type === 'time') {
      blocked = d.ms >= d.override.until;
      cause = blocked ? 'time-override' : '';
    } else if (!blocked && d.override?.type === 'episode') {
      if (item?.kind === 'episode' && item.id) {
        if (!d.override.id && item.id !== d.override.after) d.override.id = item.id;
        blocked = !!d.override.id && item.id !== d.override.id;
      } else blocked = true;
      cause = blocked ? 'episode-override' : '';
    } else if (!blocked) {
      blocked = count(d) >= s.episodes || d.ms >= s.minutes * 60000;
      cause = blocked ? (d.ms >= s.minutes * 60000 ? 'minutes' : 'episodes') : '';
    }
    return { blocked, cause, today: d, date: dayKey(now), settings: s, count: count(d), revision: d.revision };
  }
  function add(state, start, end, item) {
    // Split playback at local midnight (also respects local DST day lengths).
    while (start < end) {
      const next = new Date(start); next.setHours(24,0,0,0);
      const stop = Math.min(end, next.getTime()), d = day(state, start), ms = stop-start;
      d.ms += ms;
      if (item?.kind === 'episode' && item.id && item.title) {
        const e = d.episodes[item.id] ||= { id: item.id, title: item.title, season: item.season || null, episode: item.episode || null, episodeTitle: item.episodeTitle || '', ms: 0 };
        e.ms += ms;
      }
      start = stop;
    }
  }
  function tick(state, key, message, now) {
    const previous = state.sessions[key];
    if (!previous || message.seq > previous.seq) {
      const ms = Math.max(0, Math.min(5000, Number(message.ms) || 0));
      // Receipt time is authoritative; bounded samples cannot backfill arbitrary days.
      if (ms) add(state, now-ms, now, message.item);
      state.sessions[key] = { seq: message.seq, seen: now };
    }
    for (const [id, s] of Object.entries(state.sessions)) if (now-s.seen > 86400000) delete state.sessions[id];
    // Retain 90 calendar days, keeping local storage bounded.
    const keys = Object.keys(state.days).sort();
    while (keys.length > 90) delete state.days[keys.shift()];
    return verdict(state, message.item, now);
  }
  function choose(state, message, now) {
    const d = day(state, now);
    if (message.date !== dayKey(now) || (message.revision !== d.revision && message.choice !== 'stop')) return verdict(state, message.item, now);
    if (message.choice === 'stop') { d.stopped = true; d.override = null; }
    else if (!d.stopped && message.choice === 'time') d.override = { type: 'time', until: d.ms+30*60000 };
    else if (!d.stopped && message.choice === 'episode' && message.item?.kind === 'episode' && message.item.id) {
      d.override = { type: 'episode', id: message.ended ? null : message.item.id, after: message.ended ? message.item.id : null };
    } else return verdict(state, message.item, now);
    d.revision++;
    // An ended episode must not consume the next-episode allowance.
    return message.ended && message.choice === 'episode' ? { ...verdict(state, null, now), blocked: false } : verdict(state, message.item, now);
  }
  g.LimitEngine = { fresh, day, dayKey, count, verdict, tick, choose, MEANINGFUL_MS };
})(globalThis);
