'use strict';
const $ = id => document.getElementById(id);
let initialized = false;
async function refresh() {
  try {
    const r = await chrome.runtime.sendMessage({ type: 'get' });
    if (r.error) throw new Error(r.error);
    $('episodes').textContent = r.count;
    $('minutes').textContent = (r.today.ms/60000).toFixed(1);
    $('allowance').textContent = r.today.stopped ? 'Stopped for today.' : r.today.override?.type === 'time' ? `${Math.max(0,(r.today.override.until-r.today.ms)/60000).toFixed(1)} extra playback minutes remaining.` : r.today.override?.type === 'episode' ? 'Temporary allowance: one episode.' : `Daily limits: ${r.settings.episodes} episodes / ${r.settings.minutes} minutes.`;
    if (!initialized) {
      $('episode-limit').value = r.settings.episodes; $('minute-limit').value = r.settings.minutes;
      $('reason').value = r.settings.reason; $('diagnostic').checked = r.settings.diagnostic; initialized = true;
    }
    $('log').replaceChildren();
    for (const e of Object.values(r.today.episodes)) {
      const li = document.createElement('li'), small = document.createElement('small');
      li.textContent = `${e.title} · S${e.season} E${e.episode}${e.episodeTitle ? ` · ${e.episodeTitle}` : ''}`;
      small.textContent = `${(e.ms/60000).toFixed(1)} min · ${e.ms >= 60000 ? 'Counted' : 'Under 60 seconds — not counted yet'}`;
      li.append(small); $('log').append(li);
    }
    if (!$('log').children.length) $('log').textContent = 'No confidently identified episodes today.';
    $('diagnostics').hidden = !r.settings.diagnostic;
    if (r.settings.diagnostic) {
      const { diagnostic } = await chrome.storage.local.get('diagnostic');
      $('observation').textContent = diagnostic ? JSON.stringify(diagnostic,null,2) : 'Waiting for a Netflix player observation.';
    }
  } catch (error) { $('status').textContent = error.message; }
}
$('settings').addEventListener('submit', async event => {
  event.preventDefault();
  try {
    const result = await chrome.runtime.sendMessage({ type: 'settings', settings: { episodes: Number($('episode-limit').value), minutes: Number($('minute-limit').value), reason: $('reason').value, diagnostic: $('diagnostic').checked } });
    if (result.error) throw new Error(result.error);
    $('status').textContent = 'Saved. Temporary allowances cleared.';
    await refresh();
  } catch (error) { $('status').textContent = error.message; }
});
void refresh(); setInterval(refresh,2000);
