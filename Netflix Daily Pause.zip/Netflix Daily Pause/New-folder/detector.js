/* All Netflix-specific DOM assumptions and transition signals live here.
 * No private APIs, network interception, or invented metadata. English S/E labels
 * only in this MVP. Unknown or localized metadata still permits minute tracking.
 */
(function (g) {
  'use strict';
  function classify({ watchId, title, detail, preview }) {
    if (preview) return { kind: 'preview' };
    if (!watchId) return { kind: 'unknown' };
    const match = detail.match(/\bS(?:eason)?\s*(\d+)\s*[:.,·-]?\s*E(?:pisode)?\s*(\d+)\b/i);
    if (title && match) return { kind: 'episode', id: watchId, title, season: Number(match[1]), episode: Number(match[2]), episodeTitle: detail.slice(match.index+match[0].length).replace(/^[\s:·-]+/,'') };
    // Absence of S/E text is not proof of a movie. Unknown and movies behave alike.
    return { kind: 'unknown' };
  }
  class NetflixDetector {
    constructor() { this.watchId = null; this.signature = ''; this.stable = 0; this.cached = null; this.priorSignature = ''; this.waitFresh = false; }
    observe(doc = document, loc = location) {
      const watchId = loc.pathname.match(/^\/watch\/(\d+)/)?.[1] || null;
      const player = doc.querySelector('.watch-video, [data-uia="watch-video"]');
      const video = player ? [...player.querySelectorAll('video')].sort((a,b) => b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight)[0] : null;
      const metadata = player?.querySelector('[data-uia="video-title"], .video-title');
      const title = (metadata?.querySelector('h4, h3')?.textContent || '').trim();
      const detail = (metadata?.textContent || '').trim();
      const preview = /\b(trailer|teaser|preview)\b/i.test(detail) || !!player?.querySelector('[data-uia="preview-player"], [data-uia="trailer-player"]');
      const signature = `${title}|${detail}`;
      const transition = watchId !== this.watchId;
      if (transition) {
        this.priorSignature = this.signature;
        this.waitFresh = !!this.watchId;
        this.watchId = watchId; this.cached = null; this.stable = 0;
      }
      // During SPA navigation the old title may outlive the old watch URL.
      if (this.waitFresh && signature !== this.priorSignature) this.waitFresh = false;
      this.stable = signature === this.signature ? this.stable+1 : 0;
      this.signature = signature;
      let item = classify({ watchId, title, detail, preview });
      if (item.kind === 'episode' && (this.stable < 1 || this.waitFresh)) item = { kind: 'unknown' };
      if (item.kind === 'episode') this.cached = item;
      // Netflix hides controls/title during playback; retain only within same watch ID.
      if (!detail && this.cached && !preview) item = this.cached;
      return { video, item, key: watchId || 'outside-watch', eligible: !!watchId && !!video && !preview,
        diagnostic: { watchId, mainPlayerFound: !!player, videoFound: !!video, title, detail, preview, transition, stable: this.stable, waitingForFreshMetadata: this.waitFresh, classification: item.kind, selectors: '.watch-video / [data-uia=watch-video]; [data-uia=video-title] / .video-title' } };
    }
  }
  g.NetflixDetection = { NetflixDetector, classify };
})(globalThis);
