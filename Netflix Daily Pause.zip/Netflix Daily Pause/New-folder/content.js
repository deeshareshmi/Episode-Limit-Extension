(() => {
  'use strict';
  const detector = new NetflixDetection.NetflixDetector(), sampler = new PlaybackSampler();
  const session = crypto.randomUUID();
  let seq = 0, busy = false, attached = null, lastKey = null, status = null, observation = null;
  let host = null, shadow = null, shown = false, lastDiagnostic = 0, choosing = false, pendingPlay = false;
  const send = async message => {
    const result = await chrome.runtime.sendMessage(message);
    if (result?.error) throw new Error(result.error);
    return result;
  };
  function mount() {
    if (host?.isConnected) return;
    host = document.createElement('div');
    host.id = 'netflix-daily-pause';
    // Put the overlay inside the fullscreen element when Netflix uses fullscreen.
    (document.fullscreenElement || document.documentElement).append(host);
    shadow = host.attachShadow({ mode: 'closed' });
    shadow.innerHTML = `<style>
      :host{all:initial} [hidden]{display:none!important} .backdrop{position:fixed;inset:0;z-index:2147483647;background:#080b14dc;display:grid;place-items:center;color:#f7f8fc;font:16px/1.5 system-ui}
      .card{box-sizing:border-box;background:#151c2b;border:1px solid #627089;border-radius:16px;padding:28px;width:min(480px,90vw);box-shadow:0 20px 80px #000}
      h2{font-size:25px;margin:0 0 12px} p{white-space:pre-wrap;overflow-wrap:anywhere} button{display:block;width:100%;padding:12px;margin-top:10px;border:1px solid #8b9ab3;border-radius:8px;background:#26334b;color:white;font:inherit;cursor:pointer}button:first-of-type{background:#c83144}button:focus-visible{outline:3px solid #a9ccff}button:disabled{opacity:.5} .small{font-size:13px;color:#bcc8da}
      </style><div class="backdrop"><section class="card" role="dialog" aria-modal="true" aria-labelledby="pause-title"><h2 id="pause-title">Time for a pause</h2><p id="summary"></p><p id="reason"></p><p class="small" id="note"></p><button data-choice="stop">Stop for today</button><button data-choice="episode">Watch one more episode</button><button data-choice="time">Continue for 30 more minutes</button></section></div>`;
    shadow.addEventListener('click', async event => {
      const choice = event.target.dataset.choice;
      if (!choice || choosing || !status) return;
      choosing = true;
      try {
        status = await send({ type: 'choice', choice, date: status.date, revision: status.revision, item: observation.item, ended: !!observation.video?.ended });
        if (!status.blocked) {
          hide(); sampler.reset();
          if (!observation.video?.ended) await observation.video?.play().catch(() => {});
        } else show(status);
      } catch (error) { shadow.querySelector('#note').textContent = `Could not save choice: ${error.message}`; }
      finally { choosing = false; }
    });
    shadow.addEventListener('keydown', event => {
      if (event.key !== 'Tab') return;
      const buttons = [...shadow.querySelectorAll('button')].filter(b => !b.hidden && !b.disabled);
      const index = buttons.indexOf(shadow.activeElement);
      if (buttons.length) { event.preventDefault(); buttons[(index+(event.shiftKey ? -1 : 1)+buttons.length)%buttons.length].focus(); }
    });
  }
  function hide() { host?.remove(); host = null; shown = false; }
  function show(result) {
    mount();
    shadow.querySelector('#summary').textContent = `Your daily limits: ${result.settings.episodes} episodes or ${result.settings.minutes} minutes.\nToday: ${result.count} counted episodes and ${(result.today.ms/60000).toFixed(1)} playback minutes.`;
    shadow.querySelector('#reason').textContent = result.settings.reason;
    shadow.querySelector('#note').textContent = result.today.stopped ? 'Stopped for today. Playback unlocks at local midnight.' : result.cause === 'time-override' ? 'Your extra 30 playback minutes are used up.' : result.cause === 'episode-override' ? 'Your episode allowance has ended, or the episode cannot be identified.' : 'An episode counts after 60 seconds. An episode allowance covers this unfinished episode, or the next one if this has ended.';
    shadow.querySelector('[data-choice="episode"]').hidden = observation.item.kind !== 'episode' || result.today.stopped;
    shadow.querySelector('[data-choice="time"]').hidden = result.today.stopped;
    shadow.querySelector('[data-choice="stop"]').disabled = result.today.stopped;
    if (!shown) { shadow.querySelector('button:not([hidden]):not(:disabled)')?.focus(); shown = true; }
  }
  function attach(video) {
    if (attached === video) return;
    if (attached) for (const e of ['play','pause','seeking','seeked','ended','waiting','playing']) attached.removeEventListener(e,onMedia);
    attached = video; sampler.reset();
    if (video) for (const e of ['play','pause','seeking','seeked','ended','waiting','playing']) video.addEventListener(e,onMedia);
  }
  function onMedia(event) {
    if (event.type === 'seeking' || event.type === 'seeked' || event.type === 'waiting') sampler.reset();
    if (event.type === 'play') {
      const next = detector.observe();
      if (next.key !== lastKey || !status) { pendingPlay = true; attached.pause(); }
      else if (status.blocked) attached.pause();
    }
    void pulse();
  }
  async function pulse() {
    if (busy || choosing) return;
    busy = true;
    try {
      observation = detector.observe();
      const { video, key, eligible, item } = observation;
      attach(video);
      if (!eligible) {
        sampler.reset(); hide(); lastKey = null;
        if (Date.now()-lastDiagnostic > 5000) {
          lastDiagnostic = Date.now();
          status = await send({ type: 'get' });
          if (status.settings.diagnostic) await send({ type: 'diagnostic', observation: observation.diagnostic });
        }
        return;
      }
      const ms = sampler.sample({ key, now: performance.now(), position: video.currentTime, rate: video.playbackRate || 1, playing: !video.paused && !video.ended && video.readyState >= 2, seeking: video.seeking, eligible });
      const transition = key !== lastKey;
      const resumeAfterGate = (transition && !video.paused) || pendingPlay;
      pendingPlay = false;
      if (transition) { video.pause(); sampler.reset(); lastKey = key; }
      status = await send({ type: 'tick', session, seq: ++seq, ms, item });
      if (status.blocked) { video.pause(); sampler.reset(); show(status); }
      else { hide(); if (resumeAfterGate) await video.play().catch(() => {}); }
      if (status.settings.diagnostic && Date.now()-lastDiagnostic > 5000) {
        lastDiagnostic = Date.now();
        await send({ type: 'diagnostic', observation: { ...observation.diagnostic, paused: video.paused, seeking: video.seeking, position: video.currentTime, lastSampleMs: ms } });
      }
    } catch (error) {
      // A broken extension must not silently leave playback running without limits.
      attached?.pause();
      console.warn('[Netflix Daily Pause] Reload the tab if the extension was updated.', error);
    } finally { busy = false; }
  }
  document.addEventListener('fullscreenchange', () => { if (host) (document.fullscreenElement || document.documentElement).append(host); });
  setInterval(pulse,1000);
  void pulse();
})();
